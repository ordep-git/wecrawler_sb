package pl.coderslab.webcrawler;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebcrawlerApplicationTests {

	@Test
	void contextLoads() {
	}

}
